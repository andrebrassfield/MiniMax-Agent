# Latest Health Check

*Pending first health check.*

## What this file checks

- All dossier files have valid front matter and link to at least one source trail.
- All handoff queue files follow their schema.
- All `knowledge/*.jsonl` ledgers parse as valid JSON Lines.
- All wiki pages link to a real dossier.
- The source-balance report exists and the latest run is < 12h old.
- No orphan findings (every `fnd-` has at least one `src-`).
- Verification queue size < 50.
- Broken links: scan and count.

## Status

**PASS / DEGRADED / FAIL** — populated by `scripts/research_agent_health_check.py`.

## Last run

*YYYY-MM-DD HH:MM CT — populated by the same script.*

---

*If this file is older than 12h, the vault is structurally unhealthy. Do not trust new synthesis until the structure is fixed.*
