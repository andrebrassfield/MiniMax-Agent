# Runs

> Each refresh leaves a receipt here. If you cannot replay a run, you cannot trust its output later.

## Format

```markdown
# RUN-YYYYMMDD-HHMM

- mode: <BOOTSTRAP | REFRESH | DAILY_SUMMARY | ...>
- started_at: YYYY-MM-DD HH:MM CT
- finished_at: YYYY-MM-DD HH:MM CT
- duration_min: <number>
- collector_lanes_active: [...]
- collector_lanes_degraded: [...]
- findings_appended: <N>
- sources_appended: <N>
- claims_appended: <N>
- claims_updated: <N>
- dossiers_updated: [ai_agents, frontier_ai, ...]
- handoffs_written: {mavis: N, hermes: N, build: N, content: N, watch: N, verify: N}
- verification_queue_size_after: <N>
- source_balance_social_pct: <N>
- vault_health: PASS | DEGRADED | FAIL
- notes: "<any anomalies>"
```

## Receipts

*Empty. Append on each run.*
