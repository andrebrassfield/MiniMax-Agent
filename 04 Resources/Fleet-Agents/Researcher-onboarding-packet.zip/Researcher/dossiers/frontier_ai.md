# Dossier — Frontier AI

> Living topic file. Model releases, capability shifts, context length, multimodality.

## Why this topic matters to Andre

Andre's agents run on the frontier. Model capability changes shift his stack's ceiling — what an agent can do, how long it can grind, what modalities it can ingest. M3 is his current default; the moment a successor emerges with material capability gains, the stack needs to know.

## Current signal (last refresh: pending)

*No refresh yet.*

## Source trail

*Empty. First REFRESH will append.*

## Contradictions and open questions

- Open-weight frontier vs. closed-API frontier — where is the capability floor moving month-over-month?
- Context length claims: real working context vs. marketed context. Which vendors are honest?
- Multimodality parity: when does native video input become routine rather than premium?

## Implications

- **Build:** *(populated by REFRESH)*
- **Content:** *(claims with source trail)*
- **Watch:** *(vendor roadmaps, leak signals)*
- **Verify:** *(benchmark claims, context length claims)*

## Routing history

| Date | Routed to | Item | Outcome |
|------|-----------|------|---------|
| — | — | — | — |

---

*Dossier is the lever. Knowledge ledgers are the receipts. Refresh is the engine.*
