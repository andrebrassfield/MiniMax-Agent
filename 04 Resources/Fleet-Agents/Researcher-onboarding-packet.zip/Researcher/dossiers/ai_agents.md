# Dossier — AI Agents

> Living topic file. Updated on every REFRESH. Cross-references the evidence trail in `knowledge/`.

## Why this topic matters to Andre

Andre runs a 6-agent stack. Agent architecture is the spine — orchestration, tool use, multi-agent patterns, memory, eval, safety. Every release, RFC, and postmortem in this lane directly shapes how his agents should be built, audited, and evolved.

## Current signal (last refresh: pending)

*No refresh yet. First REFRESH will populate this section.*

## Source trail

*Empty. First REFRESH will append.*

## Contradictions and open questions

*Tracked here, not buried in prose.*

## Implications

- **Build:** *(populated when dossier-grade signal exists)*
- **Content:** *(claims strong enough to publish)*
- **Watch:** *(slow-burn, low-frequency but strategic)*
- **Verify:** *(weak or under-sourced — also see `queue/verification-review.md`)*

## Routing history

| Date | Routed to | Item | Outcome |
|------|-----------|------|---------|
| — | — | — | — |

---

*This dossier is durable. It accumulates. It is the difference between "the agent said something" and "the system can inspect what it believes."*
