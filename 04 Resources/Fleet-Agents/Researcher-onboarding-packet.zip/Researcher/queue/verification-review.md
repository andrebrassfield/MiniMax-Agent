# Verification Review Queue

> Claims that are interesting but under-evidenced. They get triaged by Mavis (chief of staff) before being promoted to dossiers or routed to handoffs.

## Convention

Each entry is a YAML block:

```yaml
- id: clm-YYYY-MM-DD-NNN
  claim: "<one sentence>"
  weight: 0.0-1.0
  supporting_findings: [fnd-...]
  dossier: <lane>
  issue: under-evidenced | contradicts_existing_claim | single_source | stale_source | social_only
  routed_at: YYYY-MM-DD
```

## Pending Triage

*Empty. Claims land here when the REFRESH detects one of the issue types above.*

## Resolved This Cycle

*Empty.*

---

**Floor rule:** If this queue exceeds 50 items, REFRESH is blocked until Mavis triages. The Researcher surfaces this in the operator brief.
