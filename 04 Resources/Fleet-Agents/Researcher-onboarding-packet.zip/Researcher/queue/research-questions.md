# Research Question Backlog

> Mavis and Andre drop questions here. Researcher processes on the next REFRESH (or immediately if flagged urgent).

## Pending

*Empty. Questions will be appended below as `### YYYY-MM-DD — <question> — <asker>`.*

## Processed

*Empty. Resolved questions move to `decisions/research-questions-resolved.md`.*

---

**Convention:**
- Use `### YYYY-MM-DD — <one-line question> — <asker>` headers.
- Below the header, link to the dossier or source if relevant.
- Mark `URGENT:` prefix if the question needs a sub-1h response.
- Researcher adds a status footer: `Status: answered in <file> on <date> | escalated to <lane> | awaiting source`.

The Researcher does not just answer — it adds the question, the source trail, and the resolved location to the dossier or claim record. Backlog is not a chat log; it is a traceable log.
