# Content Handoff — Researcher → Content Agents

> Patterns, frames, claims strong enough to publish. Source trail required.

## Pending

*Empty.*

## Convention

```yaml
- id: cnt-handoff-YYYY-MM-DD-NNN
  format: thread | longform | short_post | newsletter
  angle: "<one sentence frame>"
  core_claim: "<the publishable claim>"
  weight: 0.0-1.0
  source_trail: [src-...]
  target_audience: <founder | engineer | operator | general>
  suggested_title: "<one line>"
  routed_at: YYYY-MM-DD
```

## Recently Consumed (last 5)

*Empty.*

---

**Discipline:**
- Source trail is non-negotiable. Content agents will fact-check.
- Weight ≥ 0.7 unless format is `short_post` and the angle is "hot take with caveat."
- Frame should be novel relative to the dossier's existing angles (no retread).
