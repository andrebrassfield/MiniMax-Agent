# Watch Handoff — Researcher → Watch List

> Slow-burn topics. Low-frequency, but strategically important. Worth a glance every refresh, not worth a deep dive.

## Pending

*Empty.*

## Convention

```yaml
- id: wch-handoff-YYYY-MM-DD-NNN
  topic: "<one line>"
  why_watch: "<one sentence>"
  trigger_to_promote: "<what would push this to active research>"
  last_signal: YYYY-MM-DD
  routed_at: YYYY-MM-DD
```

## Recently Consumed (last 5)

*Empty.*

---

**Discipline:**
- Maximum 20 active watch items at any time. If you exceed, demote the oldest cold ones to `decisions/`.
- A watch item that has not produced signal in 90 days gets archived.
