# Hermes Handoff — Researcher → Hermes (fleet orchestrator)

> Route to Hermes: buildable, verified, ready-to-route work. Hermes turns this into kanban tasks for the worker pool.

## Pending (Hermes to consume)

*Empty.*

## Convention

```yaml
- id: hms-handoff-YYYY-MM-DD-NNN
  type: build_task | research_deep_dive | integration_opportunity | regression_alert
  title: "<one line>"
  dossier: <lane>
  evidence:
    claim: "<one sentence>"
    weight: 0.0-1.0
    source_trail: [src-...]
    verified: true
  scope: small | medium | large
  estimated_effort: <hours>
  depends_on: [hms-handoff-...]
  routed_at: YYYY-MM-DD
```

## Recently Consumed (last 5)

*Empty.*

---

**Discipline:**
- Verified-only. `verified: true` is required. If you have not verified, route to `queue/verify-handoff.md` instead.
- Source trail must survive audit. Hermes workers will pull it.
- Do not pre-assign workers; Hermes owns routing.
- Skip if the task is "research the X" — that is a research question for the Researcher, not a Hermes task.
