# Mavis Handoff — Researcher → Mavis (chief of staff)

> Route to Mavis: implications, weekly-feed material, "here is what changed and what matters." Mavis reads this on every cycle and uses it to brief Andre and write `06 Connections/` notes.

## Pending (Mavis to consume)

*Empty. New items appended by REFRESH.*

## Convention

```yaml
- id: mvs-handoff-YYYY-MM-DD-NNN
  type: implication | weekly_connection_seed | priority_alert | contradiction
  dossier: <lane>
  claim: "<one sentence>"
  weight: 0.0-1.0
  source_trail: [src-...]
  why_matters: "<one sentence>"
  suggested_action: "<one sentence>"
  routed_at: YYYY-MM-DD
```

## Recently Consumed (last 5)

*Empty.*

---

**Discipline:**
- Dossier-grade signal only. No weak claims, no summaries of summaries.
- Weight ≥ 0.6 unless flagged as `priority_alert`.
- Source trail required.
- Mavis will mark items consumed by moving them to the consumed list.
