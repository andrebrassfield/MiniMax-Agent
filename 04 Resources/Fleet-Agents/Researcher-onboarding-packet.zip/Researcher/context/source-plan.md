# Source Plan — Researcher

The Researcher's taste is encoded here. This is where it learns what to watch, what to skip, and how to weight what it sees.

## Operating Principle

> Prefer sources that change decisions. A wider collection is not a better collection.

If the plan collects everything, the vault drowns. If it only collects what is easy, the vault overfits to convenient APIs. This file is the balance.

## Source Lanes (current)

### ai_agents (high weight)

| Source | Type | Cadence | Notes |
|--------|------|---------|-------|
| GitHub: langchain-ai/langchain, crewAIInc/crewAI, letta-ai/letta, openai/swarm, anthropics/anthropic-sdk | primary | 6h | Watch releases, RFCs, breaking changes |
| GitHub: sigoden/aichat, mitchellh/ghostty, simonw/llm | primary | 6h | Tooling patterns |
| RSS: LangChain blog, Letta blog, Anthropic engineering | primary | 6h | Primary voice |
| X: curated "AI builders" list | social | 6h | Early signal only — verify before dossier |

### frontier_ai (high weight)

| Source | Type | Cadence | Notes |
|--------|------|---------|-------|
| OpenAI blog + release notes | primary | 6h | |
| Anthropic news + research | primary | 6h | |
| Google DeepMind blog | primary | 6h | |
| arXiv cs.AI + cs.CL (filtered by Andre's keywords) | primary | 12h | Use arxiv-sanity or HF papers API |
| Hugging Face: trending models, trending spaces | primary | 6h | |
| MiniMax releases (when public) | primary | 6h | Direct source of truth for Andre's stack |

### memory_orchestration (high weight)

| Source | Type | Cadence | Notes |
|--------|------|---------|-------|
| GitHub: letta-ai/letta, plastic-labs/honcho, mem0ai/mem0, chroma-core/chroma | primary | 6h | |
| Docs: pgvector, sqlite-vec, LanceDB, Qdrant | primary | 24h | |
| X: @mem_palace, @Letta_AI, @plastic_labs | social | 6h | Verification queue only |

### dev_tooling (high weight)

| Source | Type | Cadence | Notes |
|--------|------|---------|-------|
| Official docs for tools Andre uses (Claude Code, Codex, OpenCode, Hermes, OpenClaw) | primary | 24h | |
| GitHub releases for the same | primary | 6h | |

### research_method (medium weight)

| Source | Type | Cadence | Notes |
|--------|------|---------|-------|
| r/MachineLearning | secondary | 24h | Filter by score > 100 |
| LessWrong, AI Alignment Forum | secondary | 24h | |
| Selected Substacks (Latent Space, Interconnects, etc.) | secondary | 24h | |

### builder_patterns (low weight)

| Source | Type | Cadence | Notes |
|--------|------|---------|-------|
| Indie Hackers | secondary | 24h | Filter for AI-agent builders |
| Hacker News (filtered: AI + agents + tools) | secondary | 24h | |
| Specific Substacks on solo-founder patterns | secondary | weekly | |

### crypto_rails_agent_commerce (medium weight)

| Source | Type | Cadence | Notes |
|--------|------|---------|-------|
| Base blog + docs | primary | 24h | |
| Coinbase developer blog | primary | 24h | |
| x402 protocol updates | primary | 24h | |
| Agent commerce discussions (X, Farcaster) | social | 12h | Verify before dossier |

### robotics_embodied (low weight — watch only)

| Source | Type | Cadence | Notes |
|--------|------|---------|-------|
| Selected lab blogs (Figure, 1X, Skild AI) | primary | weekly | |
| arXiv cs.RO (filtered) | primary | weekly | |

## Weights and Tuning

- **Bump weight** when a source consistently produces dossier-grade signal (cross-source agreement, primary, fresh).
- **Demote** sources that go silent or start producing low-trust signal.
- **Add** sources when a new lane appears in `context/interest-profile.md`.
- **Remove** sources that have produced zero signal in 60 days.

Tuning decisions are recorded in `decisions/source-plan-changes.md`.

## Anti-Patterns

- **Daily-summary-of-X scrapers.** If a source's output is "here are today's headlines," it does not get dossier weight.
- **Aggregator-only sources.** If a source is repackaging other sources, demote it to the source it repackages.
- **Engagement-bait social accounts.** No matter how on-topic, if the account is "growth content," verification queue only.
- **Promotional material** (vendor blogs disguised as research). Read, but never use as primary.

## Collector Health

Per-source health is tracked in `ops/collector-health.md`. A lane that fails 3 consecutive runs is marked `degraded`, removed from the active plan, and surfaced in the operator brief.

---

*The source plan is taste. Update it like you update a chef's pantry — keep what's working, demote what isn't, never let it grow without pruning.*
