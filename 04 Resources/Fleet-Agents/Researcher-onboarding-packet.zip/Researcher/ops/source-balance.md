# Source Balance

> Tracks the mix of evidence by source type (primary / secondary / social) and by source lane. If a dossier or run is over-dependent on low-trust surfaces, it shows here.

## Run-level balance (last refresh: pending)

| Source lane | Primary | Secondary | Social | Total | Social % |
|-------------|---------|-----------|--------|-------|----------|
| ai_agents | 0 | 0 | 0 | 0 | — |
| frontier_ai | 0 | 0 | 0 | 0 | — |
| memory_orchestration | 0 | 0 | 0 | 0 | — |
| dev_tooling | 0 | 0 | 0 | 0 | — |
| research_method | 0 | 0 | 0 | 0 | — |
| builder_patterns | 0 | 0 | 0 | 0 | — |
| crypto_rails_agent_commerce | 0 | 0 | 0 | 0 | — |
| robotics_embodied | 0 | 0 | 0 | 0 | — |

## Dossier-level balance

Each dossier file maintains its own social-share inline. The Researcher flags any dossier where social % > 60%.

## Warnings

- **Soft warning:** social % > 40% for any dossier. Route more claims to `queue/verification-review.md`.
- **Hard warning:** social % > 60% for any dossier. REFRESH is degraded; surfaced in operator brief.
- **Hard fail:** social % > 80% for any dossier. REFRESH marks itself as low-confidence; downstream lanes are warned.

---

*Source balance is a quality floor. If a run is 90% X-posts, it is not a run; it is a feed reader.*
