# Operator Brief

> First thing Andre reads after a REFRESH. Tells him: what changed, what deserves attention, what is blocked by weak evidence, and what Mavis/Hermes should do.

*Pending first REFRESH. Once the first REFRESH runs, this file will be rewritten with:*

## What changed since last brief
*3-5 dossier-grade deltas, each with a source link and a one-line implication.*

## What deserves attention
*Prioritized list. Items the Researcher believes should move this cycle.*

## Blocked / under-evidenced
*Claims parked in `queue/verification-review.md` and why.*

## Handoffs ready for consumption
- Mavis: <N items in `queue/mavis-handoff.md`>
- Hermes: <N items in `queue/hermes-handoff.md`>
- Build: <N items in `queue/build-handoff.md`>
- Content: <N items in `queue/content-handoff.md`>
- Watch: <N items in `queue/watch-handoff.md`>
- Verify: <N items in `queue/verify-handoff.md`>

## Collector health
*One line per lane. Degraded lanes flagged.*

## Source balance
*Ratio of primary/secondary/social for this run. Warning if social > 40%.*

## Vault health
*Pass/fail with one-line summary.*

## Suggested next actions for Mavis
*1-3 items.*

---

**Discipline:** This file is rewritten on every REFRESH, not appended. Andre should never have to scroll.
