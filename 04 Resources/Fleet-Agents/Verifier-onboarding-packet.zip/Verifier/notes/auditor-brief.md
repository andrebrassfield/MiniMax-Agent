# Auditor Brief

> First thing Andre reads after an AUDIT. Tells him: what changed in trust posture, what deserves attention, what is blocked by audit debt, and what Mavis/Researcher/Hermes should do.

*Pending first AUDIT. Once the first AUDIT runs, this file will be rewritten with:*

## What changed in trust posture since last brief
*3-5 audit-grade deltas, each with a target artifact and a one-line implication.*

## What deserves attention
*Prioritized list. Verdicts the Verifier believes should move this cycle.*

## Audit debt
*Items parked in `queue/andre-appeal.md` (age > 48h is stale) and any NEEDS-MORE-EVIDENCE items past their SLA.*

## Verdict handoffs ready for consumption
- Researcher: <N items in `queue/researcher-verify-handoff.md`>
- Mavis: <N items in `queue/mavis-audit-handoff.md`>
- Hermes: <N items in `queue/hermes-audit-handoff.md`>
- Andre: <N appeals in `queue/andre-appeal.md`>

## Per-agent audit coverage
*Last audit date per agent. Flag if any agent is past the 7-day cadence.*

## Vault health
*Pass/fail with one-line summary.*

## Suggested next actions for Mavis
*1-3 items — usually "consume verdict handoffs" or "tune the rubric on criterion X."*

---

**Discipline:** This file is rewritten on every AUDIT, not appended. Andre should never have to scroll.
