# Audit Requests — incoming lane

> Mavis, Hermes, and the cron loop drop audit requests here. The Verifier processes them on the next AUDIT (or immediately if marked `urgent`).

## Pending (Verifier to consume)

*Empty. New items appended by requesters.*

## Convention

```yaml
- id: aud-req-YYYY-MM-DD-NNN
  requester: mavis | hermes | cron | andre
  target_agent: researcher | mavis | hermes
  target_artifact: "<artifact-id or handoff-id>"
  reason: claim_weight_dispute | handoff_audit | process_compliance_check | periodic_audit | appeal
  urgency: low | normal | high | urgent
  context: "<one sentence — what triggered this request>"
  requested_at: YYYY-MM-DD
```

## Recently Consumed (last 5)

*Empty.*

---

**Discipline:**
- The Verifier processes this queue on the next AUDIT cycle. Mark `urgent` only when the failure mode is propagating downstream.
- The Verifier does not gate AUDIT on this queue being non-empty. The cron loop runs AUDIT every 6h regardless.
- Mavis may also drop items here when she wants a second look at a claim Mavis is promoting or a connection she is about to publish.
