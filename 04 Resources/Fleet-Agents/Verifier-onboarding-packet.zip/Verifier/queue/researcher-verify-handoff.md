# Researcher Verify Handoff — Verifier → Researcher

> Verdicts on the Researcher's claims, findings, dossiers, and run compliance. The Researcher reads this on every cycle and updates the claims ledger accordingly.

## Pending (Researcher to consume)

*Empty. New verdicts appended by AUDIT.*

## Convention

```yaml
- id: vrf-handoff-YYYY-MM-DD-NNN
  audit_log_id: aud-...
  target: "<claim-id | finding-id | dossier-name | run-id>"
  verdict: PASS | FAIL | NEEDS-WORK | NEEDS-MORE-EVIDENCE
  weighted_score: 0.0-1.0
  rubric_criteria:
    source_quality: 0.0-1.0
    cross_source_agreement: 0.0-1.0
    stage_discipline: 0.0-1.0
    freshness: 0.0-1.0
    process_compliance: 0.0-1.0
    handoff_hygiene: 0.0-1.0
  trail:
    - src-...
    - raw/.../snapshot.json
  issue: "<one sentence — what was found, named as artifact not as agent>"
  recommended_action: demote_weight | require_primary_source | split_claim | surface_contradiction | promote | freeze | drop
  snapshot_as_of: YYYY-MM-DDTHH:MM:SSZ
  issued_at: YYYY-MM-DD
  temperature: 0.0
```

## Recently Consumed (last 5)

*Empty.*

---

**Discipline:**
- Every verdict has a trail. Verdicts without a trail are rejected at write time.
- The Researcher will mark items consumed by moving them to the consumed list and applying the recommended_action to the claims ledger.
- Do not pre-write the consumption action for the Researcher. They own their ledger.
- A FAIL verdict is not a "stop work" signal. It is a "down-weight or freeze" signal.
- A PASS verdict is a "this is solid; route it" signal.
