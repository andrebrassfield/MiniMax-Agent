# Dossier — Researcher Audit

> Per-agent audit dossier. Tracks the Researcher's process discipline, common failure modes, and audit history.

## Why this agent is audited

The Researcher is Andre's evidence operator. Its claim ledger, dossier deltas, and handoff lanes are upstream of Mavis, Hermes, and every decision Andre makes on a research-implication. A research agent that smudges is a hallucination laundry with extra steps.

## What the Researcher does well
*Populated by AUDIT — observed process compliance, source hygiene, handoff discipline.*

## Common failure modes to watch
- **Hallucination laundry** — confident prose without separation between observed, claimed, and verified.
- **Source monoculture** — one lane producing 80% of signal.
- **Verification debt** — `queue/verification-review.md` growing unbounded.
- **Stale freshness** — operator brief claims "as of today" but the last REFRESH is 36h old.
- **Handoff drift** — handoff queues written but never read.
- **Wiki rot** — wiki pages link to dossiers that no longer exist.

## Recent audit signal (last 5 verdicts)

| Date | Target | Verdict | Score | Issue |
|------|--------|---------|-------|-------|
| — | — | — | — | — |

## Process compliance checks (per REFRESH)
- [ ] REFRESH steps ran in order (no skipped stages)
- [ ] Source quality scored per claim
- [ ] Cross-source agreement surfaced
- [ ] Claims ledger appended (not edited in place)
- [ ] Dossiers updated with new signal
- [ ] Verification queue routed
- [ ] Operator brief rewritten (not appended)
- [ ] Handoff lanes updated
- [ ] Wiki compiled
- [ ] Indexes rebuilt
- [ ] Health check run
- [ ] Run receipt written

## Audit cadence

- **Frequency:** every AUDIT cycle, sample-check 1-2 REFRESH run receipts
- **Floor:** at least one audit per 7 days
- **SLA on FAIL verdicts:** routed to `queue/researcher-verify-handoff.md` within 24h

## Source trail

*Empty. First AUDIT will append.*
